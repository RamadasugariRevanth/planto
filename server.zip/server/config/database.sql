-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS planto_db;
USE planto_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    reset_token VARCHAR(255),
    reset_token_expires DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert admin user (password: admin123)
INSERT INTO users (name, email, password, role) VALUES 
('Admin', 'admin@planto.com', '$2a$10$mj1yXYKYM9q5j5D9YX5z7.WXryUQV5Q5S5q5D5Q5S5q5D5Q5S5q5D', 'admin')
ON DUPLICATE KEY UPDATE email=email;

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    image_url VARCHAR(255),
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert sample products
INSERT INTO products (name, description, price, stock, image_url, category) VALUES
('Snake Plant', 'Easy to care for indoor plant that purifies air', 29.99, 50, 'https://images.unsplash.com/photo-1593482892290-f54c7f4d8895', 'Indoor Plants'),
('Peace Lily', 'Beautiful flowering plant that thrives in low light', 24.99, 30, 'https://images.unsplash.com/photo-1593691509543-c55fb32e7355', 'Indoor Plants'),
('Monstera', 'Trendy plant with unique split leaves', 39.99, 25, 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b', 'Indoor Plants'),
('Succulent Set', 'Collection of 3 hardy desert plants', 19.99, 100, 'https://images.unsplash.com/photo-1459411552884-841db9b3cc2a', 'Succulents'),
('Herb Garden Kit', 'Grow your own basil, mint, and parsley', 34.99, 40, 'https://images.unsplash.com/photo-1466124517913-f7c8ed6c0ddf', 'Herbs')
ON DUPLICATE KEY UPDATE name=name;

-- Orders table
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS order_tracking;
DROP TABLE IF EXISTS orders;

CREATE TABLE IF NOT EXISTS orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    shipping_address TEXT NOT NULL,
    payment_status ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Order tracking table
CREATE TABLE IF NOT EXISTS order_tracking (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    status VARCHAR(100) NOT NULL,
    location VARCHAR(255),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);
