const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const path = require('path');

// Helper function to validate and format image URL
const formatImageUrl = (imageUrl) => {
  if (!imageUrl) {
    return 'https://via.placeholder.com/300?text=No+Image';
  }

  // If it's already a full URL, return as is
  if (imageUrl.startsWith('http')) {
    return imageUrl;
  }

  // If it's a local path, ensure it starts with /static
  if (!imageUrl.startsWith('/static')) {
    return path.join('/static', imageUrl);
  }

  return imageUrl;
};

// Get all products with filters
router.get('/', async (req, res) => {
  const connection = await req.db.getConnection();
  try {
    const { category, minPrice, maxPrice, sortBy, search } = req.query;
    
    let query = 'SELECT * FROM products WHERE 1=1';
    const params = [];

    // Apply filters
    if (category && category !== 'all') {
      query += ' AND category = ?';
      params.push(category);
    }

    if (minPrice) {
      query += ' AND price >= ?';
      params.push(parseFloat(minPrice));
    }

    if (maxPrice) {
      query += ' AND price <= ?';
      params.push(parseFloat(maxPrice));
    }

    if (search) {
      query += ' AND (name LIKE ? OR description LIKE ?)';
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm);
    }

    // Apply sorting
    if (sortBy) {
      switch (sortBy) {
        case 'price_low':
          query += ' ORDER BY price ASC';
          break;
        case 'price_high':
          query += ' ORDER BY price DESC';
          break;
        case 'newest':
          query += ' ORDER BY created_at DESC';
          break;
        case 'popular':
          query += ' ORDER BY sales_count DESC';
          break;
        default:
          query += ' ORDER BY created_at DESC';
      }
    } else {
      query += ' ORDER BY created_at DESC';
    }

    const [products] = await connection.execute(query, params);

    // Format image URLs
    products.forEach(product => {
      product.image_url = formatImageUrl(product.image_url);
    });

    res.json(products);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ message: 'Error fetching products', error: error.message });
  } finally {
    connection.release();
  }
});

// Get product by ID
router.get('/:id', async (req, res) => {
  const connection = await req.db.getConnection();
  try {
    const [products] = await connection.execute(
      'SELECT * FROM products WHERE id = ?',
      [req.params.id]
    );

    if (products.length === 0) {
      return res.status(404).json({ message: 'Product not found' });
    }

    const product = products[0];
    product.image_url = formatImageUrl(product.image_url);

    res.json(product);
  } catch (error) {
    console.error('Error fetching product:', error);
    res.status(500).json({ message: 'Error fetching product', error: error.message });
  } finally {
    connection.release();
  }
});

// Create new product (admin only)
router.post('/', auth, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }

  const connection = await req.db.getConnection();
  try {
    const { name, description, price, stock, image_url, category } = req.body;
    const formattedImageUrl = formatImageUrl(image_url);

    const [result] = await connection.execute(
      'INSERT INTO products (name, description, price, stock, image_url, category) VALUES (?, ?, ?, ?, ?, ?)',
      [name, description, price, stock, formattedImageUrl, category]
    );

    res.status(201).json({
      message: 'Product created successfully',
      productId: result.insertId
    });
  } catch (error) {
    console.error('Error creating product:', error);
    res.status(500).json({ message: 'Error creating product', error: error.message });
  } finally {
    connection.release();
  }
});

// Update product (admin only)
router.put('/:id', auth, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }

  const connection = await req.db.getConnection();
  try {
    const { name, description, price, stock, image_url, category } = req.body;
    const formattedImageUrl = formatImageUrl(image_url);

    const [result] = await connection.execute(
      'UPDATE products SET name = ?, description = ?, price = ?, stock = ?, image_url = ?, category = ? WHERE id = ?',
      [name, description, price, stock, formattedImageUrl, category, req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.json({ message: 'Product updated successfully' });
  } catch (error) {
    console.error('Error updating product:', error);
    res.status(500).json({ message: 'Error updating product', error: error.message });
  } finally {
    connection.release();
  }
});

// Delete product (admin only)
router.delete('/:id', auth, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }

  const connection = await req.db.getConnection();
  try {
    const [result] = await connection.execute(
      'DELETE FROM products WHERE id = ?',
      [req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    res.status(500).json({ message: 'Error deleting product', error: error.message });
  } finally {
    connection.release();
  }
});

module.exports = router;
