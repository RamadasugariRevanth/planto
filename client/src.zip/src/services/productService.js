import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const productService = {
  getAllProducts: async (filters = {}) => {
    try {
      const { category, priceRange, sortBy, searchQuery } = filters;
      let url = `${API_URL}/products?`;
      
      if (category && category !== 'all') url += `category=${category}&`;
      if (priceRange) url += `minPrice=${priceRange[0]}&maxPrice=${priceRange[1]}&`;
      if (sortBy) url += `sortBy=${sortBy}&`;
      if (searchQuery) url += `search=${searchQuery}&`;

      const response = await axios.get(url);
      return response.data;
    } catch (error) {
      console.error('Error fetching products:', error);
      throw error;
    }
  },

  getProductById: async (id) => {
    try {
      const response = await axios.get(`${API_URL}/products/${id}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching product:', error);
      throw error;
    }
  }
};

export default productService;
